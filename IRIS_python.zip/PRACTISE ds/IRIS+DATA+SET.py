
# coding: utf-8

# # LOADING IRIS DATA SET AND PRE-PROCESSING

# In[356]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt,pylab
import seaborn as sns
get_ipython().magic('matplotlib inline')


# In[ ]:


os.chdir("S:/PRACTISE ds")


# In[357]:


data_train=pd.read_csv("Train Data.csv",index_col=False)


# In[358]:


data_train["CLASS"].unique()


# In[ ]:


setosa=data_train[data_train['CLASS']=="Iris-setosa"]
versicolor=data_train[data_train['CLASS']=="Iris-versicolor"]
virginica=data_train[data_train['CLASS']=="Iris-virginica"]


# In[ ]:


x=versicolor["SW"]
y=versicolor["SL"]



# In[ ]:


for i in range(0, data_train.shape[1]):
    #print(i)
    if(data_train.iloc[:,i].dtypes == 'object'):
        data_train.iloc[:,i] = pd.Categorical(data_train.iloc[:,i])
        #print(marketing_train[[i]])
        data_train.iloc[:,i] = data_train.iloc[:,i].cat.codes 
        data_train.iloc[:,i] = data_train.iloc[:,i].astype('object')


# In[ ]:


data_train["CLASS"].unique()


# # DATA VISULIZATION

# In[ ]:


plt.scatter(x,y,c="Green",alpha=0.5,label='X',marker="*",s=180,edgecolors="Blue")
pylab.xlabel('Spatial Length')
pylab.ylabel('Spatial Width')
pylab.title("Spatial Width and Length Plot of Visicolor")

plt.show()


# In[ ]:


sns.boxplot(data=setosa, orient="v", palette="Set3")
pylab.title("Boxplot of Setosa after removing outliers")
pylab.ylabel("Value")
pylab.xlabel("Various factor")


# In[ ]:


sns.boxplot(y=setosa['PW'],orient='v')
sns.swarmplot(y=setosa['PW'],color=".35")


# # REMOVING OUTLIERS FROM DATA
# 

# In[ ]:


temp_data=pd.DataFrame(data_train, columns=["SL","SW","PL","PW"],index=None)
temp_data.head(2)


# In[ ]:


numeric=[]
for j in range(0,temp_data.shape[1]):
    if(temp_data.iloc[:,j].dtypes=="float64"):
        print(j)
        numeric.append(temp_data.columns[j])


# In[ ]:


q75, q25 = np.percentile(temp_data["SL"], [75 ,25])
iqr = q75 - q25
minimum = q25 - (iqr*1.5)
maximum = q75 + (iqr*1.5)
    #testdata.loc[testdata[i] < minimum,:i] = np.nan
print(maximum,minimum)


# In[ ]:



for i in numeric:
    a=0 
    for j in range(0,temp_data.shape[0]):
        if(temp_data.iloc[j][i]<minimum):
                 a=a+1
                 #print(i)
                 temp_data.loc[[j],[i]]==np.nan
print(a)
missing_val = pd.DataFrame(temp_data.isnull().sum())
print(missing_val)


# In[ ]:


from fancyimpute import KNN
temp_data = pd.DataFrame(KNN(k = 3).complete(temp_data), columns = temp_data.columns)


# AS THE OUTLIER SHOWS LESS IT NOT NEEDED TO REMOVE VALUES

# # CO-RELATION MATRIX

# In[ ]:


df_corr = data_train.loc[:,numeric]
f, ax = plt.subplots(figsize=(7, 5))
corr = df_corr.corr()
pylab.title("CO-RELATION MATRIX OF IRIS")
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax)


# In[ ]:


temp_data.hist(bins=10,figsize=(9,9))
pylab.suptitle("Histogram for each numeric input variable for NORMALITY CHECK ")


# # BULIDING MACHINE LEARNING MODEL

# In[ ]:


for i in range(0, data_train.shape[1]):
    #print(i)
    if(data_train.iloc[:,i].dtypes == 'object'):
        data_train.iloc[:,i] = pd.Categorical(data_train.iloc[:,i])
        #print(marketing_train[[i]])
        data_train.iloc[:,i] = data_train.iloc[:,i].cat.codes 
        data_train.iloc[:,i] = data_train.iloc[:,i].astype('object')


# In[360]:


Y_train


# In[388]:


from sklearn.cross_validation import train_test_split
predicted_class=['CLASS']
X=data_train[numeric].values
Y=data_train['CLASS'].values
split_test_size=0.30
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=split_test_size,random_state=42)


# In[361]:


from sklearn.naive_bayes import MultinomialNB
NB_model = MultinomialNB().fit(X_train, Y_train)


# In[362]:


pre=NB_model.predict(X_train)
from sklearn import metrics
print(metrics.accuracy_score(Y_train,pre))


# In[389]:


from sklearn import tree
C50_model = tree.DecisionTreeClassifier(criterion='entropy').fit(X_train, Y_train)


# In[390]:


pre_DT=C50_model.predict(X_train)
print(metrics.accuracy_score(Y_train,pre_DT))
#print(pre_DT)


# In[387]:


pre_DT=C50_model.predict(X_test)
print(metrics.accuracy_score(Y_test,pre_DT.round(), normalize=False))


# #CONFUSION MATRICS

# In[386]:


from sklearn.metrics import confusion_matrix 
CM = confusion_matrix(Y_train,X_train)

