
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np
from fancyimpute import KNN   
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
import seaborn as sns
from random import randrange, uniform


# In[2]:


os.chdir("S:/New folder")


# In[3]:


testdata=pd.read_csv("Test_data (1).csv")


# In[28]:


test_trial=pd.read_csv("Test_data (1).csv")


# In[5]:


testdata=testdata.drop("phone number",1)
testdata=testdata.drop("number vmail messages",1)


# In[6]:


for j in range(0,testdata.shape[1]):
    if(testdata[testdata.columns[j]].dtypes=="int64"):
        testdata[testdata.columns[j]]=testdata[testdata.columns[j]].astype('float64')


# In[ ]:


testdata['total night charge'].dtypes


# In[7]:


numeric=[]
ob=[]
for j in range(0,testdata.shape[1]):
    if(testdata.iloc[:,j].dtypes=="float64"):
        #print(j)
        numeric.append(testdata.columns[j])
for j in range(0,testdata.shape[1]):
    if(testdata.iloc[:,j].dtypes=="object"):
        #print(j)
        ob.append(testdata.columns[j])
        


# In[22]:


col


# In[10]:


for i in range(0, testdata.shape[1]):
    #print(i)
    if(testdata.iloc[:,i].dtypes == 'object'):
        testdata.iloc[:,i] = pd.Categorical(testdata.iloc[:,i])
        #print(marketing_train[[i]])
        testdata.iloc[:,i] = testdata.iloc[:,i].cat.codes 
        testdata.iloc[:,i] = testdata.iloc[:,i].astype('object')
        
        #lis.append(marketing_train.columns[i])
        


# In[11]:


testdata.head(2)


# In[ ]:


# #Plot boxplot to visualize Outliers
get_ipython().magic('matplotlib inline')
plt.boxplot(testdata['total day minutes'])


# In[12]:


#Detect and replace with NA
# #Extract quartiles
for i in numeric:
    q75, q25 = np.percentile(testdata[i], [75 ,25])
    iqr = q75 - q25
    minimum = q25 - (iqr*1.5)
    maximum = q75 + (iqr*1.5)
    testdata.loc[testdata[i] < minimum,:i] = np.nan
    testdata.loc[testdata[i] > maximum,:i] = np.nan

#Calculate missing value
missing_value = pd.DataFrame(testdata.isnull().sum())

# #Impute with KNN
#testdata = pd.DataFrame(KNN(k = 3).complete(testdata), columns = testdata.columns)


# In[13]:


missing_value


# In[14]:


testdata = pd.DataFrame(KNN(k = 3).complete(testdata), columns = testdata.columns)


# In[ ]:


testdata['Churn'].describe


#     # FEATURE SELECTION

# In[15]:


df_corr = testdata.loc[:,numeric]


# In[16]:


df_corr.head(3)


# In[17]:


#Set the width and hieght of the plot
f, ax = plt.subplots(figsize=(20, 5))

#Generate correlation matrix
corr = df_corr.corr()

#Plot using seaborn library
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(320, 10, as_cmap=True),
            square=True, ax=ax)
plt.show()


# In[19]:


testdata=testdata.drop(['total day minutes','total intl charge','total eve minutes','total night minutes'],1)


# In[24]:


ob


# In[25]:


for i in ob:
    print(i)
    chi2, p, dof, ex = chi2_contingency(pd.crosstab(testdata['Churn'], testdata[i]))
    print(p)


# In[29]:


numeric=[]
for j in range(0,test_trial.shape[1]):
    if(test_trial.iloc[:,j].dtypes=="float64"):
        #print(j)
        numeric.append(test_trial.columns[j])

#Standarisation
#col=['accoun']
#for i in col:
 #   print(i)
  #  testdata[i] = (testdata[i] - testdata[i].mean())/testdata[i].std()


# In[43]:


#Standarisation
for i in numeric:
    print(i)
    testdata[i] = (testdata[i] - testdata[i].mean())/testdata[i].std()


# In[45]:




