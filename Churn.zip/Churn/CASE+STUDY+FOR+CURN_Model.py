
# coding: utf-8

# In[1]:


import os
import pandas as pd
import numpy as np
from fancyimpute import KNN   
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency
import seaborn as sns
from random import randrange, uniform


# In[2]:


os.chdir("S:/New folder")


# In[3]:


testdata=pd.read_csv("Train_data.csv")


# In[4]:


testdata=testdata.drop("phone number",1)
testdata=testdata.drop("number vmail messages",1)


# In[5]:


for j in range(0,testdata.shape[1]):
    if(testdata[testdata.columns[j]].dtypes=="float64"):
        testdata[testdata.columns[j]]=testdata[testdata.columns[j]].astype('int64')


# In[6]:


numeric=[]
ob=[]
for j in range(0,testdata.shape[1]):
    if(testdata.iloc[:,j].dtypes=="int64"):
        #print(j)
        numeric.append(testdata.columns[j])
for j in range(0,testdata.shape[1]):
    if(testdata.iloc[:,j].dtypes=="object"):
        #print(j)
        ob.append(testdata.columns[j])
        


# In[7]:


del ob[3]


# In[8]:


for i in range(0, testdata.shape[1]):
    #print(i)
    if(testdata.iloc[:,i].dtypes == 'object'):
        testdata.iloc[:,i] = pd.Categorical(testdata.iloc[:,i])
        #print(marketing_train[[i]])
        testdata.iloc[:,i] = testdata.iloc[:,i].cat.codes 
        testdata.iloc[:,i] = testdata.iloc[:,i].astype('object')
        
        #lis.append(marketing_train.columns[i])
        


# In[9]:


testdata.head(2)


# In[ ]:


#Detect and replace with NA
# #Extract quartiles
for i in numeric:
    q75, q25 = np.percentile(testdata[i], [75 ,25])
    iqr = q75 - q25
    minimum = q25 - (iqr*1.5)
    maximum = q75 + (iqr*1.5)
    testdata.loc[testdata[i] < minimum,:i] = np.nan
    testdata.loc[testdata[i] > maximum,:i] = np.nan

# #Calculate missing value
missing_val = pd.DataFrame(testdata.isnull().sum())


# In[ ]:


#Impute with KNN
testdata = pd.DataFrame(KNN(k = 3).complete(testdata), columns = testdata.columns)


# In[ ]:


testdata['state'].dtypes


# In[10]:


# #Detect and delete outliers from data
for i in numeric:
    print(i)
    q75, q25 = np.percentile(testdata.loc[:,i], [75 ,25])
    iqr = q75 - q25

    min = q25 - (iqr*1.5)
    max = q75 + (iqr*1.5)
    print(min)
    print(max)
    
    testdata = testdata.drop(testdata[testdata.loc[:,i] < min].index)
    testdata = testdata.drop(testdata[testdata.loc[:,i] > max].index)


#     # FEATURE SELECTION

# In[11]:


df_corr = testdata.loc[:,numeric]


# In[12]:


df_corr.head(3)


# In[13]:


#Set the width and hieght of the plot
f, ax = plt.subplots(figsize=(20, 5))

#Generate correlation matrix
corr = df_corr.corr()

#Plot using seaborn library
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(320, 10, as_cmap=True),
            square=True, ax=ax)
plt.show()


# In[14]:


testdata=testdata.drop(['total day charge','total intl charge','total eve charge','total night charge'],1)


# In[ ]:


for i in ob:
    if(testdata[i].dtypes=="float64"):
        testdata[i]=testdata[i].astype('object')
testdata["Churn"]=testdata["Churn"].astype('object')


# In[17]:


numeric=[]
for j in range(0,testdata.shape[1]):
    if(testdata.iloc[:,j].dtypes=="int64"):
        #print(j)
        numeric.append(testdata.columns[j])
       


# In[ ]:


numeric


# In[16]:


for i in ob:
    print(i)
    chi2, p, dof, ex = chi2_contingency(pd.crosstab(testdata['Churn'], testdata[i]))
    print(p)


# In[18]:


#Standarisation
for i in numeric:
    print(i)
    testdata[i] = (testdata[i] - testdata[i].mean())/testdata[i].std()


# In[19]:


testdata.head(3)


# In[20]:


testdata.to_csv("Test_Final_py.csv",encoding='utf-8',index=True)


# # #BUILDING MODEL(DECESSION TREE)

# In[21]:


from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.cross_validation import train_test_split


# In[22]:


testdata['Churn'] = testdata['Churn'].replace(0.0, 'No')
testdata['Churn'] = testdata['Churn'].replace(1.0, 'Yes')


# In[23]:


test_trial=pd.read_csv("Test_Final_py.csv")


# In[39]:


test_trial['Churn'] =test_trial['Churn'].replace(0.0, 'No')
test_trial['Churn'] =test_trial['Churn'].replace(1.0, 'Yes')


# In[72]:


X = testdata.values[:, 1:14]
Y = testdata.values[:,14]

X_train, X_test, y_train, y_test = train_test_split( X, Y, test_size = 0.2)


# In[73]:


X_train


# In[74]:


C50_model = tree.DecisionTreeClassifier(criterion='gini').fit(X_train, y_train)


# In[75]:


C50_Predictions = C50_model.predict(X_test)


# In[76]:


#build confusion matrix
from sklearn.metrics import confusion_matrix 
CM = confusion_matrix(y_test, C50_Predictions)
CM = pd.crosstab(y_test, C50_Predictions)


# In[79]:


import pickle
finalmodel="final_model.sav"
pickle.dump(C50_model, open(finalmodel, 'wb'))


# In[78]:


#let us save TP, TN, FP, FN
TN = CM.iloc[0,0]
FN = CM.iloc[1,0]
TP = CM.iloc[1,1]
FP = CM.iloc[0,1]

#check accuracy of model
#accuracy_score(y_test, C50_Predictions)*100
#((TP+TN)*100)/(TP+TN+FP+FN)

#False Negative rate 
(FN*100)/(FN+TP)


# # #TEST DATA PREDICTION

# In[90]:


import pickle
X = test_trial.values[:, 2:15]
Y = test_trial.values[:,15]
loaded_model = pickle.load(open(finalmodel, 'rb'))
result = loaded_model.predict(X)
print(result)


# In[93]:


from sklearn.metrics import confusion_matrix 
CM = confusion_matrix(Y, result)
CM = pd.crosstab(Y, result)


# In[94]:


TN = CM.iloc[0,0]
FN = CM.iloc[1,0]
TP = CM.iloc[1,1]
FP = CM.iloc[0,1]


# In[97]:


#check accuracy of model
#accuracy_score(Y, result)*100
((TP+TN)*100)/(TP+TN+FP+FN)

#False Negative rate 
(FN*100)/(FN+TP)

