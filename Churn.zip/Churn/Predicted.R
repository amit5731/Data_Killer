rm(list=ls())
setwd("S:/New folder")
trial_data=read.csv("Train_data.csv", header=T)
trial_data=trial_data[,-4]

numeric_index = sapply(trial_data,is.numeric)
numeric_data = trial_data[,numeric_index]
cnames = colnames(numeric_data)

## Correlation Plot
library(corrgram)
corrgram(trial_data[,numeric_index], order = F,
         upper.panel=panel.pie, text.panel=panel.txt, main = "Correlation Plot")
set.seed(7)
library(caret)
co_re=cor(numeric_data[,1:16])
print(co_re)
highco=findCorrelation(co_re,cutoff=0.75)
print(highco)

## Chi-squared Test of Independence
factor_index = sapply(trial_data,is.factor)
factor_data = trial_data[,factor_index]
for (i in 1:4)
{
  print(names(factor_data)[i])
  print(chisq.test(table(factor_data$Churn,factor_data[,i])))
}

## Dimension Reduction
trial_data = subset(trial_data,select = -c(number.vmail.messages,total.day.charge,total.eve.charge,total.night.minutes,total.intl.charge))
summary(trial_data)                    

library(ggplot2)
 for (i in 1:length(cnames))
{
   assign(paste0("gn",i), ggplot(aes_string(y = (cnames[i]), x = "Churn"), data = subset(trial_data))+ 
            stat_boxplot(geom = "errorbar", width = 0.5) +
            geom_boxplot(outlier.colour="red", fill = "grey" ,outlier.shape=18,
                         outlier.size=1, notch=FALSE) +
            theme(legend.position="bottom")+
            labs(y=cnames[i],x="responded")+
            ggtitle(paste("Box plot of responded for",cnames[i])))
 }                    

# ## Plotting plots together
gridExtra::grid.arrange(gn1,gn10,ncol=2)


# #loop to replace by NA
 for(i in cnames){
   val = trial_data[,i][trial_data[,i] %in% boxplot.stats(trial_data[,i])$out]
   print(length(val))
   trial_data[,i][trial_data[,i] %in% val] = NA
 }
# # #loop to remove from all variables
 for(i in cnames){
   print(i)
   val = trial_data[,i][trial_data[,i] %in% boxplot.stats(trial_data[,i])$out]
   #print(length(val))
   trial_data = trial_data[which(!trial_data[,i] %in% val),]
 }
 
library(DMwR)
trial_data = knnImputation(trial_data, k = 3)
summary(trial_data)
cnames
hist(trial_data$account.length)
#Standardisation
 for(i in cnames){
   print(i)
   trial_data[,i] = (trial_data[,i] - mean(trial_data[,i]))/
                                  sd(trial_data[,i])
 }
summary(trial_data)

for(i in 1:ncol(trial_data)){
  
  if(class(trial_data[,i]) == 'factor'){
    
    trial_data[,i] = factor(trial_data[,i], labels=(1:length(levels(factor(trial_data[,i])))))
    
  }
}
summary(trial_data$Churn)

library(DataCombine)
rmExcept("trial_data")
#write.csv(trial_data,file = "Test_final.csv")
test_date=read.csv("Test_final.csv", header = TRUE)
test_date=test_date[,-1]
#####MODEL FOR DECESSION TREE###########
library(C50)
C50_model = C5.0(Churn ~.,test_date, trials=100,rules=TRUE)
#test_date$Churn=factor(test_date$Churn)
#class(test_date$Churn)
summary(C50_model)
prediction=predict(C50_model,test_date[,-15], type="class")
confusion=table(test_date$Churn,prediction)
confusionmatrix=confusionMatrix(confusion)

write(capture.output(summary(C50_model)), "c50Rules.txt")

